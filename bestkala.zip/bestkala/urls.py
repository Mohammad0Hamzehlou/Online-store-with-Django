
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('shop.urls')),
    path('cart/', include('cart.urls')), 
    path('store/', include('store.urls')), 
    path('hello/', include('hello.urls')),
    path('checkout/', include('checkout.urls')),
    path('cart2/', include('cart2.urls')),
    path('media-manager/', include('media_manager.urls')),

]

# اضافه کردن مسیر فایل‌های استاتیک و رسانه‌ای در حالت توسعه
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
