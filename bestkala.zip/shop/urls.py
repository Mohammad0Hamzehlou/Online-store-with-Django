from django.urls import path
from . import views
from .views import register

urlpatterns = [
    path('', views.page_1, name="home"),
    path('about/', views.about, name="about"),
    path('logout/', views.logout_user, name="logout"),
    path('signup/', views.signup_user, name='signup'),
    path('login/', views.login_user, name='login'),
    path('success/', views.success_view, name='success'),
    path('Product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('category/<int:category_id>/', views.category_products, name='category'),
    path('register/', register, name='register'),
    

]