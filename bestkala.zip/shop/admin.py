from django.contrib import admin
from .import models




admin.site.register(models.cat)
admin.site.register(models.cust)
admin.site.register(models.product)
admin.site.register(models.order)
admin.site.register(models.Text)