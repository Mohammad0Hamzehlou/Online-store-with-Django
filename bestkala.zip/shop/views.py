from django.shortcuts import render, redirect, get_object_or_404
from .models import product, cat
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.urls import reverse
from .models import Text
from django.core.paginator import Paginator
from django.urls import reverse
from .forms import CustRegistrationForm 

def page_1(request):
    all_product = product.objects.all()
    return render(request, 'index.html', {'products': all_product})

def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "خوش آمدید")  # پیام موفقیت برای کاربر
            return redirect("home")  # هدایت به صفحه اصلی پس از ورود
        else:
            messages.error(request, "خطا در احراز هویت")
            return redirect("login")
    return render(request, 'login.html')


def logout_user(request):
    logout(request)
    
    return redirect("home")






def signup_user(request):
    if request.method == 'POST':
        form = CustRegistrationForm(request.POST)
        if form.is_valid():
            # اگر فرم معتبر باشد، کاربر را ذخیره می‌کند
            user = form.save()
        else:
            # اگر فرم نامعتبر باشد، کاربر را به‌طور دستی ایجاد می‌کند
            user = User.objects.create_user(
                username=request.POST.get('username'),
                password=request.POST.get('password1'),
                first_name=request.POST.get('first_name'),
                last_name=request.POST.get('last_name'),
                email=request.POST.get('email'),
            )
            user.save()
        
        # پس از ایجاد کاربر، احراز هویت و ورود خودکار
        user = authenticate(username=user.username, password=request.POST.get('password1'))
        if user is not None:
            login(request, user)
            messages.success(request, "ثبت نام با موفقیت انجام شد. خوش آمدید!")
            return redirect('home')  # به صفحه اصلی یا هر صفحه دیگری که مایل هستید هدایت کنید
    else:
        form = CustRegistrationForm()
    
    return render(request, 'signup.html', {'form': form})




# shop/views.py



def product_detail(request, product_id):
    Product = get_object_or_404(product, id=product_id)
    add_to_cart_url = reverse('cart:add_to_cart', args=[Product.id])
    return render(request, 'product.html', {'Product': Product, 'add_to_cart_url': add_to_cart_url})

def category_products(request,category_id):
    try:
        category =  get_object_or_404(cat, id=category_id)
        products = category.products.all()
        return render(request, 'category.html', {"category":category, 'products':products}) 
    except:
        return redirect ("home")



def about(request):
    text = Text.objects.first() 
    return render(request, 'about_us.html', {'text': text})
    







def register(request):
    if request.method == 'POST':
        form = CustRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "ثبت نام با موفقیت انجام شد")
            return redirect('success')  # حالا این باید کار کند
    else:
        form = CustRegistrationForm()
    return render(request, 'signup.html', {'form': form})

    
    

 
def success_view(request):
    return render(request, 'success.html')  # یک قالب success.html ایجاد کنید