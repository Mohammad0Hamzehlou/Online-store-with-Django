from django.contrib import admin
from .import models




admin.site.register(models.Ca)

admin.site.register(models.Pr)