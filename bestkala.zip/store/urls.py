#urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.store, name="store"),
    path('Pr/<int:Pr_id>/', views.Pr_detail, name='pr_detail'),
    path('Ca/<int:Ca_id>/', views.Ca_products, name='ca'),
]