#models.py

from django.db import models

class Ca(models.Model):
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class Pr(models.Model):
    name = models.CharField(max_length=15)
    discription = models.CharField(max_length=500, default='', blank=True, null=True)
    price = models.DecimalField(max_digits=12, default=0, decimal_places=0)
    category = models.ForeignKey(Ca, on_delete=models.CASCADE, default=1)
    image = models.ImageField(upload_to='upload/pr/', default='', blank=True, null=True)
    is_sall = models.BooleanField(default=False)
    sale_price = models.DecimalField(default=0, decimal_places=0, max_digits=12)

    def __str__(self):
        return self.name