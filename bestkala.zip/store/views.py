from django.shortcuts import render, get_object_or_404
from django.urls import reverse
from .models import Pr, Ca
# store/views.py


def store(request):
    all_product = Pr.objects.all()
    
    # ایجاد URL داینامیک برای هر محصول
    for product in all_product:
        product.add_to_cart_url = reverse('cart2:add_to_cart', args=[product.id])
    
    return render(request, 'store.html', {'products': all_product})


def Pr_detail(request, Pr_id):
    pr = get_object_or_404(Pr, id=Pr_id)
    add_to_cart_url = reverse('cart:add_to_cart', args=['store', pr.id])  # 'store' به عنوان پارامتر source اضافه شده است
    return render(request, 'product.html', {'pr': pr, 'add_to_cart_url': add_to_cart_url})

def Ca_products(request, Ca_id):
    ca = get_object_or_404(Ca, id=Ca_id)
    pr = Pr.objects.filter(category=ca)
    return render(request, 'category.html', {"ca": ca, 'pr': pr})
