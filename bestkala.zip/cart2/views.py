# cart2/views.py
from django.shortcuts import redirect, render, get_object_or_404
from .models import CartItem
from store.models import Pr

def add_to_cart(request, product_id):
    product = get_object_or_404(Pr, id=product_id)
    
    # چک کردن اینکه آیا محصول قبلاً به سبد خرید اضافه شده است یا خیر
    cart_item, created = CartItem.objects.get_or_create(
        product_name=product.name,
        defaults={
            'product_image': product.image,
            'description': product.discription,
            'price': product.sale_price if product.is_sall else product.price,
            'quantity': 1,
            'total_price': product.sale_price if product.is_sall else product.price
        }
    )
    
    if not created:
        cart_item.quantity += 1
        cart_item.calculate_total_price()
        cart_item.save()

    return redirect('cart2:view_cart')

def view_cart(request):
    cart_items = CartItem.objects.all()
    total_amount = sum(item.total_price for item in cart_items)
    
    return render(request, 'cart2/view_cart.html', {'cart_items': cart_items, 'total_amount': total_amount})
def remove_from_cart(request, item_id):
    item = get_object_or_404(CartItem, id=item_id)
    item.delete()
    return redirect('cart2:view_cart')
