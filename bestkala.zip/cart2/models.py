# cart2/models.py
from django.db import models
from store.models import Pr

class CartItem(models.Model):
    product_name = models.CharField(max_length=255)
    product_image = models.ImageField(upload_to='cart/', blank=True, null=True)
    description = models.CharField(max_length=500, blank=True, null=True)
    price = models.DecimalField(max_digits=12, decimal_places=0, default=0)
    quantity = models.PositiveIntegerField(default=1)
    total_price = models.DecimalField(max_digits=12, decimal_places=0, default=0)

    def calculate_total_price(self):
        self.total_price = self.quantity * self.price
        self.save()

    def __str__(self):
        return self.product_name
