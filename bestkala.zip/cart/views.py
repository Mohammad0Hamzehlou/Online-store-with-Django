# cart/views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Cart, CartItem
from django.shortcuts import redirect, get_object_or_404
from .models import Cart, CartItem
from shop.models import product  # مدل محصول از اپلیکیشن shop
from django.contrib.auth.decorators import login_required

def get_cart(request):
    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
    else:
        cart = None
    return cart
# cart/views.py



@login_required
def add_to_cart(request, product_id):
    cart, created = Cart.objects.get_or_create(user=request.user)
    product_instance = get_object_or_404(product, id=product_id)
    
    # بررسی وجود محصول در سبد خرید و افزایش مقدار آن در صورت وجود
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product_instance)
    if not created:
        cart_item.quantity += 1
    cart_item.save()

    return redirect('cart:cart_view')  # یا هر ویوی که می‌خواهید کاربر پس از افزودن به آنجا هدایت شود


def remove_from_cart(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id)
    cart_item.delete()
    return redirect('cart:cart_view')

def cart_view(request):
    cart = get_cart(request)
    total_price = sum(item.product.price * item.quantity for item in cart.items.all()) if cart else 0  # فرض بر این است که price یک ویژگی در مدل Product است
    return render(request, 'cart/cart_view.html', {'cart': cart, 'total_price': total_price})




