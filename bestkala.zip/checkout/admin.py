# checkout/admin.py

from django.contrib import admin
from .models import UserInfo
from django.utils.html import format_html

class UserInfoAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'phone_number', 'email', 'product')
    readonly_fields = ('image_tag',)  # نمایش تصویر در پنل ادمین

    def image_tag(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="150" height="150" />'.format(obj.image.url))
        return "-"
    image_tag.short_description = 'Uploaded Image'

admin.site.register(UserInfo, UserInfoAdmin)
