# checkout/views.py

from django.shortcuts import render, redirect
from .forms import UserInfoForm
from django.contrib import messages
from django.conf import settings
from kavenegar import KavenegarAPI, APIException, HTTPException

def send_sms_to_admin(user_info):
    try:
        api = KavenegarAPI(settings.KAVENEGAR_API_KEY)
        message = (
            f"اطلاعات کاربر جدید:\n"
            f"نام: {user_info.first_name} {user_info.last_name}\n"
            f"تلفن: {user_info.phone_number}\n"

            f"محصول: {user_info.product.name if user_info.product else 'No Product'}"
        )
        params = {
            'receptor': settings.ADMIN_PHONE_NUMBER,
            'message': message,
        }
        response = api.sms_send(params)
        print("SMS Response:", response)
    except APIException as e:
        print(f"APIException: {str(e)}")
    except HTTPException as e:
        print(f"HTTPException: {str(e)}")

def checkout_view(request):
    if request.method == 'POST':
        form = UserInfoForm(request.POST, request.FILES)
        if form.is_valid():
            user_info = form.save()  # ذخیره اطلاعات کاربر در پایگاه داده
            send_sms_to_admin(user_info)  # ارسال پیامک به ادمین با اطلاعات کاربر
            messages.success(request, "اطلاعات شما با موفقیت ثبت شد و به ادمین ارسال شد.")
            return redirect('checkout:checkout_success')
    else:
        form = UserInfoForm()

    return render(request, 'checkout/checkout_form.html', {'form': form})

def checkout_success(request):
    return render(request, 'checkout/checkout_success.html')
