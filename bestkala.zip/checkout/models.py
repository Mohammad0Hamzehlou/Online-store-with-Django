# checkout/models.py

from django.db import models
from shop.models import product  # فرض بر این است که مدل محصول در اپلیکیشن shop به نام Product وجود دارد

class UserInfo(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=15)
    address = models.TextField()
    postal_code = models.CharField(max_length=10)
    email = models.EmailField()
    image = models.ImageField(upload_to='user_images/')  # مسیر آپلود تصویر
    product = models.ForeignKey(product, on_delete=models.SET_NULL, null=True, blank=True)  # محصول انتخابی

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.product.name if self.product else 'No Product'}"
