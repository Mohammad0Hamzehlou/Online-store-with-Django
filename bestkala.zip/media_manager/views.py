from django.shortcuts import render
from .models import MediaFile

def media_gallery(request):
    media_files = MediaFile.objects.all()
    return render(request, 'media_manager/gallery.html', {'media_files': media_files})




def view_media_files(request):
    # دریافت همه فایل‌های رسانه‌ای از دیتابیس
    media_files = MediaFile.objects.all()
    return render(request, 'media_manager/view_media_files.html', {'media_files': media_files})
