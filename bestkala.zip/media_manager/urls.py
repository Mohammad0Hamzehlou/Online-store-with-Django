# media_manager/urls.py
from django.urls import path
from . import views

app_name = 'media_manager'  # تعریف فضای نام

urlpatterns = [
    path('images/', views.view_media_files, name='view_media_files'),
]
