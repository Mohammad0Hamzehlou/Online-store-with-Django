from django.db import models

class MediaFile(models.Model):
    MEDIA_TYPE_CHOICES = (
        ('image', 'Image'),
        ('video', 'Video'),
    )
    
    title = models.CharField(max_length=100)
    file = models.FileField(upload_to='media_files/')
    media_type = models.CharField(max_length=5, choices=MEDIA_TYPE_CHOICES)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

    def is_image(self):
        return self.media_type == 'image'
